/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan3;

import javax.swing.*;
import java.awt.event.*;
/**
 *
 * @author RECKY
 */
public abstract class Latihan3 implements ActionListener{

    /**
     * @param args the command line arguments
     */
    private static void createAndShowGUI() {
        //buat frame
        JFrame frame = new JFrame("I am a JFrame");  
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(20,30,300,100);
        frame.getContentPane().setLayout(null);
        
        //buat tombol
        JButton butt = new JButton("Click Me");
        frame.getContentPane().add(butt);
        butt.setBounds(20,20,200,20);
        
        //membuat instance objek aplikasi
        Latihan3 app = new Latihan3() {};
        
        //buat label
        app.label = new JLabel("Nama saya merupakan");
        app.label.setBounds(20,40,200,20);
        frame.getContentPane().add(app.label);
        
        //mengatur objek aplikasi
        butt.addActionListener(app);
        frame.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e) {
        //Ini akan dieksekusi ketika button diklik
        //clickCount++;
        label.setText("Ronny Jubhari");
    }
    
    public static void main(String[] args) {
        // Memulai Swing GUI
        SwingUtilities.invokeLater(new Runnable(){
            public void run() {
                createAndShowGUI();
            }
        });
    }
    //fields objek aplikasi
    //int clickCount=0;
    JLabel label;
}
